import os
import re
import time
from dotenv import load_dotenv
from typing import List, Dict, Any, Optional
import asyncio
import json
import faiss
import pickle
import numpy as np
from pathlib import Path

from pydantic import BaseModel, Field
from openai import AsyncAzureOpenAI
from pydantic_ai import Agent
from pydantic_ai.models.openai import OpenAIModel
from pydantic_ai.providers.openai import OpenAIProvider
from pydantic_ai.exceptions import ModelHTTPError

# --- Configuration ---
load_dotenv()

AZURE_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION")
AZURE_CHAT_DEPLOYMENT_NAME = os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME")

FAISS_INDEX_PATH = "vector_store/faiss_index.bin"
FAISS_METADATA_PATH = "vector_store/faiss_metadata.pkl"

# --- Pydantic Models ---
class DocumentChunk(BaseModel):
    page_content: str = Field(..., description="The textual content of the chunk.")
    metadata: Dict[str, Any] = Field(..., description="Metadata associated with the chunk, e.g., page number, source filename, chunk index.")
    embedding: Optional[List[float]] = Field(default=None, description="The embedding vector for the chunk content.")

class FaissIndexWithMetadata:
    def __init__(self, index_path: str, metadata_path: str):
        self.index_path = index_path
        self.metadata_path = metadata_path
        self.index: Optional[faiss.Index] = None
        self.document_chunks: Optional[List[DocumentChunk]] = None

    async def load(self):
        print(f"Attempting to load FAISS index from '{self.index_path}' and metadata from '{self.metadata_path}'...")
        try:
            if not os.path.exists(self.index_path) or not os.path.exists(self.metadata_path):
                raise FileNotFoundError("FAISS index or metadata files not found.")

            self.index = faiss.read_index(self.index_path)
            with open(self.metadata_path, 'rb') as f:
                self.document_chunks = pickle.load(f)
            for chunk in self.document_chunks:
                if chunk.embedding and isinstance(chunk.embedding, list):
                    chunk.embedding = np.array(chunk.embedding, dtype='float32')
            print("FAISS index and metadata loaded successfully.")
            print(f"Loaded {self.index.ntotal} embeddings and {len(self.document_chunks)} document chunks.")
        except FileNotFoundError as e:
            print(f"Warning: {e}. Please ensure your ingestion script has been run to index documents.")
            raise
        except Exception as e:
            print(f"Error loading FAISS index or metadata: {e}")
            raise

# --- Initialize Azure OpenAI Client ---
async_openai_client = AsyncAzureOpenAI(
    azure_endpoint=AZURE_ENDPOINT,
    api_version=AZURE_API_VERSION,
    api_key=AZURE_API_KEY,
)

# --- Agent Models ---
chat_model = OpenAIModel(
    AZURE_CHAT_DEPLOYMENT_NAME,
    provider=OpenAIProvider(openai_client=async_openai_client),
)

error_handling_agent = Agent(
    name="ErrorHandlingAgent",
    model=chat_model,
    description="Handles errors or unclear requests by providing helpful messages to the user.",
    output_type=str
)

class TranslationIntent(BaseModel):
    task_type: str = Field(..., description="Type of translation task: 'document', 'page', 'section', 'unclear', 'unspecified_language'.")
    target_language: str = Field(..., description="The target language for translation (e.g., 'Spanish', 'French', 'unspecified').")
    filename: Optional[str] = Field(None, description="The specific PDF filename if the request is for a document, page, or section.")
    page_number: Optional[int] = Field(None, description="The page number if the request is for a specific page.")
    section_name: Optional[str] = Field(None, description="The name of the section if the request is for a specific section (case-insensitive for general text matching).")
    message: Optional[str] = Field(None, description="A message if the intent is unclear or language is unspecified, or for error handling.")

class TranslationPlan(BaseModel):
    steps: List[str] = Field(..., description="A list of step-by-step instructions for translating the content.")
    extracted_content_type: str = Field(..., description="The type of content to be extracted: 'document_chunks', 'page_content', 'section_content'.")
    target_language: str = Field(..., description="The target language for translation.")
    filename: Optional[str] = Field(None, description="The specific PDF filename related to the plan.")
    page_number: Optional[int] = Field(None, description="The page number related to the plan.")
    section_name: Optional[str] = Field(None, description="The section name related to the plan.")

class TranslationResult(BaseModel):
    success: bool = Field(..., description="Whether the translation was successful.")
    translated_content: str = Field(..., description="The translated content or error message.")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata about the translation.")

# --- Translation Team Agents ---
user_intent_agent = Agent(
    name="UserIntentAndLanguageDetectionAgent",
    model=chat_model,
    description="Analyzes user queries to determine the intended translation task and target language.",
    output_type=TranslationIntent
)

translation_planning_agent = Agent(
    name="TranslationPlanningAgent",
    model=chat_model,
    description="Creates a detailed, step-by-step plan for translating the content based on user intent.",
    output_type=TranslationPlan
)

translation_execution_agent = Agent(
    name="TranslationExecutionAgent",
    model=chat_model,
    description="Executes the translation plan by coordinating content retrieval and translation.",
    output_type=TranslationResult
)

async def translate_text_chunk(text: str, target_language: str, metadata: Dict[str, Any]) -> str:
    """Helper function to translate a single text chunk with metadata context."""
    try:
        system_prompt = f"""You are a highly skilled and professional translator. Your task is to accurately translate the provided text into {target_language}.

**Context**: This text is from a document with the following metadata:
- Source File: {metadata.get('source_filename', 'Unknown')}
- Page Number: {metadata.get('page_number', 'N/A')}
- Chunk Index: {metadata.get('chunk_index', 'N/A')}

**Formatting Rules**:
1. Output in paragraph format only - no tables, lists, or special formatting.
2. Convert any tables, charts, or structured data into flowing paragraph text.
3. If a table, image, chart, or non-text element is present, include a description like: '[Table from Page X: contains data about...]' or '[Image from Page X: shows...]'.
4. Maintain all information as natural, flowing sentences and paragraphs.
5. Use proper sentence structure and paragraph breaks for readability.
6. Do not use markdown table syntax, bullet points, or numbered lists.
7. Convert any structured data into descriptive sentences.
8. Convert the whole output as markdown format with ### for major headings, ## for page numbers"""

        response = await async_openai_client.chat.completions.create(
            model=AZURE_CHAT_DEPLOYMENT_NAME,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": text}
            ],
            temperature=0.3,
            max_tokens=4000
        )
        return response.choices[0].message.content if response.choices and response.choices[0].message.content else ""
    except Exception as e:
        print(f"An unexpected error occurred during translation of chunk: {e}")
        return f"[Translation Failed for chunk: {str(e)}]"

async def translate_document_workflow(filename: str, target_language: str, faiss_data: FaissIndexWithMetadata) -> str:
    """Translates the entire document by processing its chunks with page and chunk metadata."""
    print(f"Translating entire document: '{filename}' to '{target_language}'")
    all_chunks = get_document_chunks_by_filename(filename, faiss_data)
    
    if not all_chunks:
        return f"Error: No content found for document '{filename}'. Please ensure it was ingested."

    translated_chunks = []
    for i, chunk in enumerate(all_chunks):
        print(f"Translating chunk {i+1}/{len(all_chunks)} (Page {chunk.metadata.get('page_number', 'N/A')}, Chunk {chunk.metadata.get('chunk_index', 'N/A')})...")
        try:
            translated_text = await translate_text_chunk(chunk.page_content, target_language, chunk.metadata)
            # Prepend metadata to the translated text for clarity
            metadata_label = f"[Page {chunk.metadata.get('page_number', 'N/A')}, Chunk {chunk.metadata.get('chunk_index', 'N/A')}]"
            translated_chunks.append(f"{metadata_label}\n{translated_text}")
        except Exception as e:
            print(f"Failed to translate chunk {i+1}: {e}. Skipping this chunk.")
            translated_chunks.append(f"[Page {chunk.metadata.get('page_number', 'N/A')}, Chunk {chunk.metadata.get('chunk_index', 'N/A')}]
[Translation Failed for chunk {i+1}]")
    
    return "\n\n".join(translated_chunks)

async def translate_page_workflow(filename: str, page_number: int, target_language: str, faiss_data: FaissIndexWithMetadata) -> str:
    """Translates a specific page of the document with page metadata."""
    print(f"Translating page {page_number} of '{filename}' to '{target_language}'")
    page_content = get_page_content(filename, page_number, faiss_data)

    if not page_content:
        return f"Error: No content found for page {page_number} in '{filename}'. Please check page number and filename."

    try:
        metadata = {"source_filename": filename, "page_number": page_number, "chunk_index": "N/A"}
        translated_text = await translate_text_chunk(page_content, target_language, metadata)
        return f"[Page {page_number}]\n{translated_text}"
    except Exception as e:
        print(f"Failed to translate page {page_number}: {e}")
        return f"[Page {page_number}]\nError translating page {page_number} of '{filename}'."

async def translate_section_workflow(filename: str, section_name: str, target_language: str, faiss_data: FaissIndexWithMetadata) -> str:
    """Translates a specific section of the document with section metadata."""
    print(f"Translating section '{section_name}' of '{filename}' to '{target_language}'")
    section_content = get_section_content(filename, section_name, faiss_data)

    if not section_content:
        return f"Error: No content found for section '{section_name}' in '{filename}'. Please provide a more precise section name if possible or ensure it exists."

    try:
        metadata = {"source_filename": filename, "section_name": section_name, "page_number": "N/A", "chunk_index": "N/A"}
        translated_text = await translate_text_chunk(section_content, target_language, metadata)
        return f"[Section: {section_name}]\n{translated_text}"
    except Exception as e:
        print(f"Failed to translate section '{section_name}': {e}")
        return f"[Section: {section_name}]\nError translating section '{section_name}' of '{filename}'."

def process_translation_for_markdown(content: str) -> str:
    """Process the translated content to ensure proper markdown paragraph formatting with metadata separation."""
    try:
        # Split content by double newlines to separate chunks or sections
        parts = content.split("\n\n")
        processed_parts = []
        
        for part in parts:
            part = part.strip()
            if not part:
                continue
            
            # Check if the part starts with a metadata label (e.g., [Page X, Chunk Y] or [Section: Z])
            if part.startswith("["):
                # Keep the metadata label as is and process the rest
                lines = part.split("\n", 1)
                metadata_label = lines[0]
                content_text = lines[1] if len(lines) > 1 else ""
                
                # Process the content text
                content_lines = content_text.split('\n')
                processed_lines = []
                
                for line in content_lines:
                    line = line.strip()
                    if not line:
                        continue
                    
                    # Remove any markdown table syntax
                    if '|' in line and line.count('|') >= 2:
                        cells = [cell.strip() for cell in line.split('|') if cell.strip()]
                        if cells:
                            line = ' '.join(cells) + '.'
                    
                    # Remove markdown list syntax
                    line = re.sub(r'^\s*[-*+]\s+', '', line)
                    line = re.sub(r'^\s*\d+\.\s+', '', line)
                    
                    # Remove excessive markdown formatting
                    line = re.sub(r'\*\*(.*?)\*\*', r'\1', line)
                    line = re.sub(r'\*(.*?)\*', r'\1', line)
                    
                    if line:
                        processed_lines.append(line)
                
                processed_content = ' '.join(processed_lines)
                processed_content = re.sub(r'\s+', ' ', processed_content).strip()
                
                if processed_content:
                    processed_parts.append(f"{metadata_label}\n{processed_content}")
            else:
                # If no metadata label, treat as plain content (unlikely but handle for robustness)
                lines = part.split('\n')
                processed_lines = []
                
                for line in lines:
                    line = line.strip()
                    if not line:
                        continue
                    
                    if '|' in line and line.count('|') >= 2:
                        cells = [cell.strip() for cell in line.split('|') if cell.strip()]
                        if cells:
                            line = ' '.join(cells) + '.'
                    
                    line = re.sub(r'^\s*[-*+]\s+', '', line)
                    line = re.sub(r'^\s*\d+\.\s+', '', line)
                    line = re.sub(r'\*\*(.*?)\*\*', r'\1', line)
                    line = re.sub(r'\*(.*?)\*', r'\1', line)
                    
                    if line:
                        processed_lines.append(line)
                
                processed_content = ' '.join(processed_lines)
                processed_content = re.sub(r'\s+', ' ', processed_content).strip()
                
                if processed_content:
                    processed_parts.append(processed_content)
        
        return "\n\n".join(processed_parts)
    except Exception as e:
        print(f"Error processing translation content: {e}")
        return content

def save_translation_to_file(translated_content: str, plan: TranslationPlan) -> str:
    """Save translated content to a markdown file with clear separation by page and section."""
    try:
        translations_dir = Path("translations")
        translations_dir.mkdir(parents=True, exist_ok=True)
        if plan.extracted_content_type == "document_chunks":
            base_name = f"{Path(plan.filename).stem}_translated_{plan.target_language}"
        elif plan.extracted_content_type == "page_content":
            base_name = f"{Path(plan.filename).stem}_page_{plan.page_number}_translated_{plan.target_language}"
        elif plan.extracted_content_type == "section_content":
            safe_section_name = re.sub(r'[^\w\s-]', '', plan.section_name).strip().replace(' ', '_')
            base_name = f"{Path(plan.filename).stem}_section_{safe_section_name}_translated_{plan.target_language}"
        else:
            base_name = f"translation_{plan.target_language}"
        
        md_filename = translations_dir / f"{base_name}.md"
        md_filename = md_filename.resolve()  # Ensure absolute path with correct separator
        
        processed_content = process_translation_for_markdown(translated_content)
        
        md_content = f"""# Translation to {plan.target_language}

**Original Document:** {plan.filename or 'N/A'}  
**Translation Type:** {plan.extracted_content_type.replace('_', ' ').title()}  
**Target Language:** {plan.target_language}  
**Generated:** {time.strftime('%Y-%m-%d %H:%M:%S')}  

**Note:** This translation is formatted as flowing paragraphs, with each paragraph labeled by its source (e.g., page number, section, or table). Tables, images, charts, or other structured elements are described within the text and converted to paragraph format for readability.

---

{processed_content}
"""
        
        with open(md_filename, 'w', encoding='utf-8') as f:
            f.write(md_content)
        
        return str(md_filename)
        
    except Exception as e:
        print(f"Error saving translation to file: {e}")
        return ""

# --- Content Retrieval Functions ---
def get_document_chunks_by_filename(filename: str, faiss_data: FaissIndexWithMetadata) -> List[DocumentChunk]:
    if not faiss_data.document_chunks:
        return []
    # Only use the filename (not full path) for matching
    filename_only = Path(filename).name
    return sorted(
        [chunk for chunk in faiss_data.document_chunks if chunk.metadata.get("source_filename") == filename_only],
        key=lambda x: (x.metadata.get("page_number", 0), x.metadata.get("chunk_index", 0))
    )

def get_page_content(filename: str, page_number: int, faiss_data: FaissIndexWithMetadata) -> str:
    if not faiss_data.document_chunks:
        return ""
    filename_only = Path(filename).name
    page_chunks_sorted = sorted(
        [chunk for chunk in faiss_data.document_chunks
         if chunk.metadata.get("source_filename") == filename_only and chunk.metadata.get("page_number") == page_number],
        key=lambda x: x.metadata.get("chunk_index", 0)
    )
    return " ".join([chunk.page_content for chunk in page_chunks_sorted])

def get_section_content(filename: str, section_name: str, faiss_data: FaissIndexWithMetadata) -> str:
    if not faiss_data.document_chunks:
        return ""
    filename_only = Path(filename).name
    section_content_parts = []
    section_pattern = re.compile(r'\b' + re.escape(section_name) + r'\b', re.IGNORECASE)
    relevant_chunks = []
    found_section_start = False
    for chunk in sorted(faiss_data.document_chunks, key=lambda x: (x.metadata.get("page_number", 0), x.metadata.get("chunk_index", 0))):
        if chunk.metadata.get("source_filename") == filename_only:
            if section_pattern.search(chunk.page_content):
                found_section_start = True
                relevant_chunks.append(chunk)
            elif found_section_start:
                if len(chunk.page_content) < 100 and (chunk.page_content.isupper() or chunk.page_content.istitle()):
                    break
                relevant_chunks.append(chunk)
    for chunk in relevant_chunks:
        section_content_parts.append(chunk.page_content)
    if not section_content_parts:
        return ""
    return " ".join(section_content_parts)

async def execute_translation_plan(plan: TranslationPlan, faiss_data: FaissIndexWithMetadata) -> TranslationResult:
    try:
        if plan.extracted_content_type == "document_chunks":
            if not plan.filename:
                return TranslationResult(
                    success=False,
                    translated_content="Error: Filename is required for document translation.",
                    metadata={"error_type": "missing_filename"}
                )
            translated_content = await translate_document_workflow(plan.filename, plan.target_language, faiss_data)
            
        elif plan.extracted_content_type == "page_content":
            if not plan.filename or plan.page_number is None:
                return TranslationResult(
                    success=False,
                    translated_content="Error: Filename and page number are required for page translation.",
                    metadata={"error_type": "missing_parameters"}
                )
            translated_content = await translate_page_workflow(plan.filename, plan.page_number, plan.target_language, faiss_data)
            
        elif plan.extracted_content_type == "section_content":
            if not plan.filename or not plan.section_name:
                return TranslationResult(
                    success=False,
                    translated_content="Error: Filename and section name are required for section translation.",
                    metadata={"error_type": "missing_parameters"}
                )
            translated_content = await translate_section_workflow(plan.filename, plan.section_name, plan.target_language, faiss_data)
            
        else:
            return TranslationResult(
                success=False,
                translated_content=f"Error: Unknown content type '{plan.extracted_content_type}'.",
                metadata={"error_type": "unknown_content_type"}
            )
        
        success = not translated_content.startswith("Error:")
        saved_filename = ""
        if success:
            saved_filename = save_translation_to_file(translated_content, plan)
        
        return TranslationResult(
            success=success,
            translated_content=translated_content,
            metadata={
                "content_type": plan.extracted_content_type,
                "target_language": plan.target_language,
                "filename": plan.filename,
                "page_number": plan.page_number,
                "section_name": plan.section_name,
                "saved_file": saved_filename
            }
        )
        
    except Exception as e:
        return TranslationResult(
            success=False,
            translated_content=f"Error executing translation plan: {str(e)}",
            metadata={"error_type": "execution_error", "exception": str(e)}
        )
