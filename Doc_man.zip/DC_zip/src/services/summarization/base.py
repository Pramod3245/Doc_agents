"""
Base classes and interfaces for summarization service
"""

from abc import ABC, abstractmethod
from typing import Dict, Any

class BaseSummarizer(ABC):
    """Base class for summarization implementations"""
    
    @abstractmethod
    async def summarize_page(self, file_path: str, page_number: int, **kwargs) -> Dict[str, Any]:
        """Summarize a specific page"""
        pass

    @abstractmethod
    async def summarize_section(self, file_path: str, section_text: str, **kwargs) -> Dict[str, Any]:
        """Summarize a specific section"""
        pass

    @abstractmethod
    async def summarize_document(self, file_path: str, **kwargs) -> Dict[str, Any]:
        """Summarize entire document"""
        pass
