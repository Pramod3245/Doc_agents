"""
Exceptions for summarization service
"""

class SummarizationError(Exception):
    """Base exception for summarization service"""
    pass

class TextExtractionError(SummarizationError):
    """Raised when text extraction from a document fails"""
    pass

class SummaryGenerationError(SummarizationError):
    """Raised when summary generation fails"""
    pass

class VectorDBError(SummarizationError):
    """Raised when vector database operations fail"""
    pass

class ConfigurationError(SummarizationError):
    """Raised when there's a configuration error"""
    pass
