"""
Configuration for summarization service
"""

import os
from pathlib import Path
from pydantic import BaseSettings

class SummarizationConfig(BaseSettings):
    """Configuration settings for summarization service"""
    # Azure OpenAI settings
    azure_endpoint: str = os.getenv("AZURE_OPENAI_ENDPOINT", "")
    azure_api_key: str = os.getenv("AZURE_OPENAI_API_KEY", "")
    azure_api_version: str = os.getenv("AZURE_OPENAI_API_VERSION", "2023-05-15")
    azure_deployment: str = os.getenv("AZURE_OPENAI_DEPLOYMENT", "")

    # Vector database settings
    vector_model_name: str = os.getenv("VECTORDB_MODEL_NAME", "BAAI/bge-base-en-v1.5")
    chunk_size: int = int(os.getenv("VECTORDB_CHUNK_SIZE", "500"))
    chunk_overlap: int = int(os.getenv("VECTORDB_CHUNK_OVERLAP", "50"))

    # Timeout settings
    summary_timeout: int = int(os.getenv("SUMMARY_TIMEOUT", "300"))
    refinement_timeout: int = int(os.getenv("REFINEMENT_TIMEOUT", "120"))

    # Retry settings
    max_retries: int = int(os.getenv("MAX_RETRIES", "3"))
    min_retry_wait: int = int(os.getenv("MIN_RETRY_WAIT", "4"))
    max_retry_wait: int = int(os.getenv("MAX_RETRY_WAIT", "10"))

    class Config:
        env_file = Path(__file__).parent.parent.parent.parent / "src/utils/.env"
        case_sensitive = False
