"""
Pydantic models for summarization service
"""

from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field

class SummaryRequest(BaseModel):
    """Model for summary request parameters"""
    content: str = Field(..., description="The content to summarize")
    style: str = Field(default="professional", description="Style of the summary")
    detail_level: str = Field(default="concise", description="Level of detail in the summary")
    focus: str = Field(default="main points", description="What to focus on in the summary")

class SummaryResponse(BaseModel):
    """Model for summary response"""
    summary: str = Field(..., description="The generated summary")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata about the summary")
    context_chunks: List[Any] = Field(default_factory=list, description="Relevant context chunks used")
