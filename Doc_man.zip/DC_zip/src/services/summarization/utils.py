"""
Utility functions for summarization service
"""

import logging
from typing import List
import PyPDF2
from pathlib import Path

logger = logging.getLogger(__name__)

def extract_text_from_pdf(file_path: str) -> str:
    """Extract text content from a PDF file"""
    try:
        with open(file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            return "\n\n".join(
                page.extract_text()
                for page in pdf_reader.pages
                if page.extract_text().strip()
            )
    except Exception as e:
        logger.error(f"Error extracting text from PDF {file_path}: {str(e)}")
        raise

def chunk_text(text: str, chunk_size: int, overlap: int) -> List[str]:
    """Split text into chunks with overlap"""
    chunks = []
    start = 0
    text_length = len(text)

    while start < text_length:
        end = min(start + chunk_size, text_length)
        chunk = text[start:end]
        chunks.append(chunk)
        start += chunk_size - overlap

    return chunks

def validate_pdf_path(file_path: str) -> Path:
    """Validate PDF file path and return Path object"""
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")
    if path.suffix.lower() != '.pdf':
        raise ValueError(f"File is not a PDF: {file_path}")
    return path
