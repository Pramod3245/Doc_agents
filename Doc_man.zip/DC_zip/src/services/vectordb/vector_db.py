"""
Vector database implementation for document storage and retrieval using FAISS
"""

import os
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
from pathlib import Path
import traceback
from PyPDF2 import PdfReader
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
import pickle
from dotenv import load_dotenv

# Load environment variables
load_dotenv(dotenv_path=Path(__file__).resolve().parent.parent.parent / "utils/.env", override=True)

# --- Pydantic Models ---
class DocumentChunk(BaseModel):
    page_content: str = Field(..., description="The textual content of the chunk.")
    metadata: Dict[str, Any] = Field(..., description="Metadata associated with the chunk, e.g., page number, source filename, chunk index.")
    embedding: Optional[List[float]] = Field(default=None, description="The embedding vector for the chunk content.")

class VectorDB:
    def __init__(self):
        # Load configuration from environment variables or use defaults
        self.model_name = os.getenv("VECTORDB_MODEL_NAME", "BAAI/bge-base-en-v1.5")
        self.chunk_size = int(os.getenv("VECTORDB_CHUNK_SIZE", "500"))
        self.chunk_overlap = int(os.getenv("VECTORDB_CHUNK_OVERLAP", "50"))
        
        # Set up paths
        self.vector_store_dir = Path(__file__).resolve().parent / "vector_store"
        self.vector_store_dir.mkdir(exist_ok=True)
        
        self.faiss_index_path = self.vector_store_dir / "faiss_index.bin"
        self.faiss_metadata_path = self.vector_store_dir / "faiss_metadata.pkl"

        # Initialize the embedding model
        print(f"Loading embedding model: {self.model_name}")
        self.model = SentenceTransformer(self.model_name)
        print(f"Embedding model loaded with dimension {self.model.get_sentence_embedding_dimension()}")

    def extract_chunks_from_pdf(self, file_path: Path) -> List[DocumentChunk]:
        """Extract text chunks from a PDF file"""
        chunks = []
        reader = PdfReader(file_path)
        file_name = file_path.name

        for page_num, page in enumerate(reader.pages):
            try:
                text = page.extract_text()
                if not text:
                    continue
                
                # Basic clean-up
                text = text.replace("\n", " ").strip()
                
                # Split into chunks with overlap
                current_chunk_index = 0
                start = 0
                while start < len(text):
                    end = min(len(text), start + self.chunk_size)
                    chunk_text = text[start:end]
                    
                    chunk = DocumentChunk(
                        page_content=chunk_text,
                        metadata={
                            "source_filename": file_name,
                            "page_number": page_num + 1,
                            "chunk_index": current_chunk_index,
                        }
                    )
                    chunks.append(chunk)
                    
                    start += self.chunk_size - self.chunk_overlap
                    current_chunk_index += 1
                    
            except Exception as e:
                print(f"Warning: Failed to extract page {page_num+1} from {file_name}: {e}")
                traceback.print_exc()

        return chunks

    def process_pdfs(self, pdf_dir: str):
        """Process all PDFs in the given directory and update the vector store"""
        document_chunks: List[DocumentChunk] = []
        texts_to_embed = []

        print("--- Starting PDF Ingestion ---")
        for file in Path(pdf_dir).glob("*.pdf"):
            print(f"Processing: {file.name}")
            try:
                chunks_from_file = self.extract_chunks_from_pdf(file)
                document_chunks.extend(chunks_from_file)
                texts_to_embed.extend([chunk.page_content for chunk in chunks_from_file])
            except Exception as e:
                print(f"Failed to process {file.name}: {e}")
                traceback.print_exc()

        print(f"Total chunks extracted: {len(document_chunks)}")

        if not document_chunks:
            print("No chunks extracted. Exiting without creating FAISS index.")
            return

        # Generate embeddings
        print("Generating embeddings...")
        embeddings_np = self.model.encode(texts_to_embed, convert_to_numpy=True, normalize_embeddings=True)
        print(f"Generated {embeddings_np.shape[0]} embeddings of dimension {embeddings_np.shape[1]}")

        # Add embeddings back to the DocumentChunk objects
        for i, chunk in enumerate(document_chunks):
            chunk.embedding = embeddings_np[i].tolist()

        # Store in FAISS
        dimension = embeddings_np.shape[1]
        index = faiss.IndexFlatL2(dimension)
        index.add(embeddings_np)
        faiss.write_index(index, str(self.faiss_index_path))
        print(f"Embeddings stored in FAISS index at '{self.faiss_index_path}'")

        # Save metadata separately
        with open(self.faiss_metadata_path, "wb") as f:
            pickle.dump(document_chunks, f)
        print(f"Metadata (DocumentChunk objects) stored at '{self.faiss_metadata_path}'")

    def search_similar(self, query: str, k: int = 5) -> List[DocumentChunk]:
        """Search for similar document chunks given a query"""
        # Load the FAISS index
        if not self.faiss_index_path.exists():
            raise FileNotFoundError("FAISS index not found. Process documents first.")
        
        index = faiss.read_index(str(self.faiss_index_path))
        
        # Load metadata
        with open(self.faiss_metadata_path, "rb") as f:
            document_chunks = pickle.load(f)
            
        # Generate query embedding
        query_embedding = self.model.encode([query], convert_to_numpy=True, normalize_embeddings=True)
        
        # Search
        D, I = index.search(query_embedding, k)
        
        # Return the matched chunks
        return [document_chunks[i] for i in I[0]]


# Example usage:
if __name__ == "__main__":
    # Initialize VectorDB
    vector_db = VectorDB()
    
    # Process PDFs (if needed)
    pdf_dir = "./pdfs"  # Adjust this path as needed
    if not vector_db.faiss_index_path.exists():
        vector_db.process_pdfs(pdf_dir)
    
    # Example search
    query = "What is the main topic of this document?"
    results = vector_db.search_similar(query)
    for i, result in enumerate(results, 1):
        print(f"\nResult {i}:")
        print(f"Content: {result.page_content[:200]}...")
        print(f"Source: {result.metadata['source_filename']}, Page: {result.metadata['page_number']}")
